
let taskInput = document.getElementById("taskInput");
let taskSubmit = document.getElementById("taskSubmit");
let displayTask = document.getElementById("displayTask");
let clearAllTask = document.getElementById("clear");
let tasks = [];

taskSubmit.addEventListener("click", function () {
  if (taskInput.value == "") {
    alert("Insert a value first");
  } else {
    if (null === localStorage.getItem("Tasks")) {
      tasks = [];
    } else {
      tasks = JSON.parse(localStorage.getItem("Tasks"));
    }
    tasks.push(taskInput.value);
    let data = JSON.stringify(tasks);
    localStorage.setItem("Tasks", data);
    location.reload();
  }
});
  let totalData = JSON.parse(localStorage.getItem("Tasks"));
  totalData.forEach(function (value,index) {
    let taskLi = document.createElement("li");
    taskLi.innerHTML = value;
    displayTask.append(taskLi);
    let crossIcon = document.createElement("input");
    crossIcon.type = "button";
    crossIcon.value = "X";
    crossIcon.id = index;
    crossIcon.style.margin = "10px";
    taskLi.appendChild(crossIcon);

});


clearAllTask.addEventListener("click", function(){
  localStorage.clear();
  location.reload();
})




